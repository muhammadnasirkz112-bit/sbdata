<?php
declare(strict_types=1);
const PH='/^0\d{10}$/';
const SPEC=[ // service => [target regex|null, mode]
 'airtime'=>[PH,'amount'],'data'=>[PH,'plan'],'data_card'=>[null,'plan'],'recharge_pin'=>[null,'plan'],
 'electricity'=>['/^\d{11,13}$/','amount'],'cable_tv'=>['/^\d{10,11}$/','plan'],
 'waec_pin'=>[PH,'plan'],'neco_pin'=>[PH,'plan'],'jamb_pin'=>[PH,'plan'],
 'bvn_check'=>['/^\d{11}$/','plan'],'nin_check'=>['/^\d{11}$/','plan']];
/** Provider adapters live in app/providers/<service_code>.php (see README there). */
function provider(string $code):?object{
 if(!preg_match('/^[a-z_]+$/',$code))return null;
 $f=__DIR__.'/providers/'.$code.'.php';if(!is_file($f))return null;
 require_once $f;$c='Provider_'.$code;return class_exists($c)?new $c():null;
}
function present(array $o):array{
 $d=($o['status']==='success'&&$o['delivery_enc'])?json_decode(dec((string)$o['delivery_enc']),true):null;
 return ['ref'=>$o['ref'],'service'=>$o['service_code'],'status'=>$o['status'],'amount_kobo'=>(int)$o['amount_kobo'],'target'=>$o['target'],'qty'=>(int)$o['qty'],'message'=>$o['message'],'delivery'=>$d,'created_at'=>$o['created_at']];
}
function order_request(array $u,array $b):array{
 $code=(string)($b['service']??'');$spec=SPEC[$code]??null;
 $s=$spec?q('SELECT * FROM services WHERE code=? AND active=1',[$code])->fetch():false;
 if(!$s)fail('This service is not available.',404);
 $idem=(string)($b['idem']??'');if(!preg_match('/^[A-Za-z0-9-]{8,64}$/',$idem))fail('Missing request id.');
 $t=trim((string)($b['target']??''));if($spec[0]&&!preg_match($spec[0],$t))fail('Check the number you entered.');
 if(in_array($code,['bvn_check','nin_check'],true)&&empty($b['consent']))fail('Consent from the ID owner is required.');
 $net=(string)($b['network']??'');if($net!==''&&!preg_match('/^[A-Za-z0-9 ]{1,20}$/',$net))fail('Invalid provider.');
 $maxq=['data_card'=>50,'recharge_pin'=>20][$code]??1;$qty=(int)($b['qty']??1);
 if($qty<1||$qty>$maxq)fail("Quantity must be from 1 to $maxq.");
 $p=null;
 if($spec[1]==='plan'){
  $p=q('SELECT * FROM products WHERE id=? AND service_code=? AND active=1',[(int)($b['product_id']??0),$code])->fetch();
  if(!$p)fail('Choose a plan.');$amt=(int)$p['price_kobo']*$qty;
 }else{
  $amt=kobo($b['amount']??'');$qty=1;
  if(($s['min_kobo']!==null&&$amt<(int)$s['min_kobo'])||($s['max_kobo']!==null&&$amt>(int)$s['max_kobo']))fail('Amount is outside the allowed range.');
 }
 if($amt<1)fail('Invalid amount.');
 return place($u,$s,$p?:null,$t,$qty,$amt,$idem,$net);
}
function place(array $u,array $s,?array $p,string $target,int $qty,int $amt,string $idem,string $net):array{
 $find=fn()=>q('SELECT * FROM orders WHERE user_id=? AND idem=?',[$u['id'],$idem])->fetch();
 if($o=$find())return present($o);
 $code=$s['code'];$stock=$code==='recharge_pin';$prov=$stock?null:provider($code);
 if(!$stock&&!$prov)fail('This service is not available yet.',503);
 $network=$p['network']??($net!==''?$net:null);
 $mask=in_array($code,['bvn_check','nin_check'],true)?str_repeat('*',max(0,strlen($target)-4)).substr($target,-4):$target;
 $pdo=db();$pdo->beginTransaction();
 try{
  $pins=[];
  if($stock){
   $pins=q("SELECT id,serial,pin_enc FROM pins WHERE network=? AND face_kobo=? AND status='available' ORDER BY id LIMIT $qty FOR UPDATE",[$p['network'],$p['face_kobo']])->fetchAll();
   if(count($pins)<$qty)throw new RuntimeException('Not enough pins in stock for that choice.');
  }
  q('INSERT INTO orders(ref,user_id,service_code,product_id,network,target,qty,amount_kobo,status,idem) VALUES(?,?,?,?,?,?,?,?,?,?)',
   [ref('SBD'),$u['id'],$code,$p['id']??null,$network,$mask,$qty,$amt,$stock?'success':'pending',$idem]);
  $oid=(int)$pdo->lastInsertId();
  ledger((int)$u['id'],'debit',$amt,'order',$oid,$s['name']);
  if($stock){
   $lines=[];
   foreach($pins as $x){q("UPDATE pins SET status='sold',order_id=? WHERE id=?",[$oid,$x['id']]);$lines[]=['serial'=>$x['serial'],'pin'=>dec((string)$x['pin_enc'])];}
   q('UPDATE orders SET delivery_enc=? WHERE id=?',[enc(json_encode($lines)),$oid]);
  }
  $pdo->commit();
 }catch(Throwable $e){
  if($pdo->inTransaction())$pdo->rollBack();
  if($e instanceof PDOException){ // PDOException extends RuntimeException, so test it first
   if((string)$e->getCode()==='23000'&&($o=$find()))return present($o); // same request id sent twice
   throw $e;
  }
  if($e instanceof RuntimeException)fail($e->getMessage(),409);
  throw $e;
 }
 if($prov){
  $o=q('SELECT * FROM orders WHERE id=?',[$oid])->fetch();
  $rid=date('YmdHi').bin2hex(random_bytes(5)); // provider request id (Lagos date prefix); stored first so a lost reply can be re-queried
  q('UPDATE orders SET provider_ref=? WHERE id=?',[$rid,$oid]);
  try{$res=$prov->purchase(['ref'=>$o['ref'],'request_id'=>$rid,'service'=>$code,'network'=>$network,'target'=>$target,'user_phone'=>$u['phone'],'qty'=>$qty,'amount_kobo'=>$amt,'product'=>$p]);}
  catch(Throwable $e){error_log((string)$e);$res=['status'=>'pending','message'=>'Waiting for provider confirmation.'];}
  $st=in_array($res['status']??'',['success','failed'],true)?$res['status']:'pending';
  $msg=substr((string)($res['message']??''),0,250);
  if($st==='pending')q('UPDATE orders SET message=? WHERE id=?',[$msg,$oid]);
  else finish_order($oid,$st,$msg,isset($res['delivery'])&&is_array($res['delivery'])?$res['delivery']:null);
 }
 audit((int)$u['id'],'order','order',$oid,['service'=>$code,'amount_kobo'=>$amt]);
 return present(q('SELECT * FROM orders WHERE id=?',[$oid])->fetch());
}

/** Settles a pending order once: success keeps the debit, failed refunds the wallet. Safe to call twice. */
function finish_order(int $oid,string $st,string $msg,?array $delivery=null):bool{
 $pdo=db();$pdo->beginTransaction();
 try{
  $o=q("SELECT * FROM orders WHERE id=? AND status='pending' FOR UPDATE",[$oid])->fetch();
  if(!$o){$pdo->rollBack();return false;}
  if($st==='failed')ledger((int)$o['user_id'],'credit',(int)$o['amount_kobo'],'refund',$oid,'Refund '.$o['ref']);
  q('UPDATE orders SET status=?,message=?,delivery_enc=? WHERE id=?',[$st,$msg,$delivery?enc(json_encode($delivery)):null,$oid]);
  $pdo->commit();return true;
 }catch(Throwable $e){$pdo->rollBack();throw $e;}
}
