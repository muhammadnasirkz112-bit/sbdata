<?php
declare(strict_types=1);
date_default_timezone_set('Africa/Lagos');
(function(){
 $f=dirname(__DIR__).'/.env';if(!is_file($f))return;
 foreach(file($f,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES) as $l){
  $l=trim($l);if($l===''||$l[0]==='#'||!str_contains($l,'='))continue;
  [$k,$v]=explode('=',$l,2);$_ENV[trim($k)]=trim(trim($v),'"\'');
 }
})();
function env(string $k,string $d=''):string{if(isset($_ENV[$k]))return $_ENV[$k];$v=getenv($k);return $v!==false?$v:$d;}
function db():PDO{
 static $p=null;if($p)return $p;
 $p=new PDO('mysql:host='.env('DB_HOST','localhost').';dbname='.env('DB_NAME').';charset=utf8mb4',env('DB_USER'),env('DB_PASS'),
  [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
 $p->exec("SET time_zone='+01:00'");return $p;
}
function q(string $sql,array $a=[]):PDOStatement{$s=db()->prepare($sql);$s->execute($a);return $s;}
function cnt(string $sql,array $a=[]):int{return (int)q($sql,$a)->fetch()['c'];}
function out(mixed $d,int $c=200):never{http_response_code($c);header('Content-Type: application/json; charset=utf-8');echo json_encode($d,JSON_UNESCAPED_UNICODE);exit;}
function fail(string $m,int $c=400):never{out(['error'=>$m],$c);}
function body():array{static $b=null;if($b===null){$j=json_decode((string)file_get_contents('php://input'),true);$b=is_array($j)?$j:[];}return $b;}
function ip():string{return substr($_SERVER['REMOTE_ADDR']??'',0,45);}
function boot():void{
 session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>env('COOKIE_SECURE','1')==='1','httponly'=>true,'samesite'=>'Lax']);
 session_name('sbd');session_start();
 if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(16));
}
function user():?array{
 static $u=null;if(empty($_SESSION['uid']))return null;
 if($u===null)$u=q('SELECT * FROM users WHERE id=?',[$_SESSION['uid']])->fetch()?:null;
 if(!$u||$u['status']!=='active'){unset($_SESSION['uid']);return null;}
 return $u;
}
function need(?string $role=null):array{$u=user();if(!$u)fail('Please log in.',401);if($role&&$u['role']!==$role)fail('Not allowed.',403);return $u;}
function csrf():void{if(!hash_equals((string)$_SESSION['csrf'],(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))fail('Session expired. Refresh the page and try again.',419);}
function limit(string $k,int $max,int $secs):void{
 $now=time();$k=substr($k,0,250);
 q('INSERT INTO rate_limits(k,hits,reset_at) VALUES(?,1,?) ON DUPLICATE KEY UPDATE hits=IF(reset_at<?,1,hits+1),reset_at=IF(reset_at<?,?,reset_at)',[$k,$now+$secs,$now,$now,$now+$secs]);
 if(cnt('SELECT hits c FROM rate_limits WHERE k=?',[$k])>$max)fail('Too many attempts. Please wait and try again.',429);
}
function kobo(mixed $v):int{
 $v=trim((string)$v);if(!preg_match('/^\d{1,9}(\.\d{1,2})?$/',$v))fail('Enter a valid amount.');
 [$n,$f]=array_pad(explode('.',$v),2,'');return (int)$n*100+(int)str_pad($f,2,'0');
}
function ref(string $p):string{return $p.'-'.strtoupper(bin2hex(random_bytes(5)));}
function audit(?int $actor,string $action,string $entity='',mixed $id=null,array $meta=[]):void{
 q('INSERT INTO audit_logs(actor_id,action,entity,entity_id,meta,ip) VALUES(?,?,?,?,?,?)',[$actor,$action,$entity,$id===null?null:(string)$id,json_encode($meta),ip()]);
}
function ledger(int $uid,string $type,int $amt,string $kind,?int $order,string $note=''):int{
 $u=q('SELECT balance_kobo FROM users WHERE id=? FOR UPDATE',[$uid])->fetch();
 if(!$u)throw new RuntimeException('Account not found.');
 $bal=(int)$u['balance_kobo'];
 if($type==='debit'&&$bal<$amt)throw new RuntimeException('Insufficient wallet balance.');
 $new=$type==='debit'?$bal-$amt:$bal+$amt;
 q('UPDATE users SET balance_kobo=? WHERE id=?',[$new,$uid]);
 q('INSERT INTO transactions(ref,user_id,type,amount_kobo,balance_after_kobo,kind,order_id,note) VALUES(?,?,?,?,?,?,?,?)',[ref('TX'),$uid,$type,$amt,$new,$kind,$order,$note]);
 return $new;
}
function appkey():string{$k=base64_decode(env('APP_KEY'),true);if($k===false||strlen($k)!==32)fail('Server is not configured (APP_KEY).',500);return $k;}
function enc(string $s):string{$iv=random_bytes(12);$c=openssl_encrypt($s,'aes-256-gcm',appkey(),OPENSSL_RAW_DATA,$iv,$tag);return base64_encode($iv.$tag.$c);}
function dec(string $s):string{$r=base64_decode($s,true)?:'';$p=openssl_decrypt(substr($r,28),'aes-256-gcm',appkey(),OPENSSL_RAW_DATA,substr($r,0,12),substr($r,12,16));return $p===false?'':$p;}
function setting(string $k):string{$r=q('SELECT v FROM settings WHERE k=?',[$k])->fetch();return $r?(string)$r['v']:'';}
function pub(array $u):array{return ['id'=>(int)$u['id'],'name'=>$u['name'],'email'=>$u['email'],'phone'=>$u['phone'],'role'=>$u['role'],'balance_kobo'=>(int)$u['balance_kobo']];}

// Integration keys can be saved from Admin > Integrations (stored in the settings table; secrets are encrypted). They override .env.
const INT_KEYS=['PAYSTACK_SECRET_KEY'=>true,'VTPASS_ENV'=>false,'VTPASS_API_KEY'=>true,'VTPASS_PUBLIC_KEY'=>true,'VTPASS_SECRET_KEY'=>true];
function cfg(string $k,string $d=''):string{
 static $c=null;
 if($c===null){$c=[];try{foreach(q("SELECT k,v FROM settings WHERE k LIKE 'cfg\\_%'")->fetchAll() as $r)$c[substr($r['k'],4)]=(string)$r['v'];}catch(Throwable $e){}}
 if(isset($c[$k])&&$c[$k]!==''){$v=(INT_KEYS[$k]??false)?dec($c[$k]):$c[$k];if($v!=='')return $v;}
 return env($k,$d);
}
