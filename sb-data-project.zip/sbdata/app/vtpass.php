<?php
declare(strict_types=1);
require_once __DIR__.'/http.php';
// VTpass REST API. Docs: https://vtpass.com/documentation/  (auth: api-key + secret-key on POST, api-key + public-key on GET)
// VTPASS_ENV=sandbox (default) or live. Request ids must start with YYYYMMDDHHmm in Africa/Lagos time (core.php sets that timezone).
const VT_FAILED=['091','016','010','011','012','013','017','018','019','021','022','023','024','027','028','030','031','032','034','035','085','087'];
function vt_configured():bool{return cfg('VTPASS_API_KEY')!==''&&cfg('VTPASS_SECRET_KEY')!==''&&cfg('VTPASS_PUBLIC_KEY')!=='';}
function vt_base():string{return cfg('VTPASS_ENV','sandbox')==='live'?'https://vtpass.com/api':'https://sandbox.vtpass.com/api';}
function vt_amt(int $kobo){return $kobo%100?$kobo/100:intdiv($kobo,100);}
/** Maps a VTpass response to success | pending | failed. Anything unclear is "pending" (never success, never an automatic refund). */
function vt_norm(?array $j,bool $requery):array{
 if(!$j)return ['status'=>'pending','message'=>'No response from provider yet.'];
 $code=(string)($j['code']??'');$desc=(string)($j['response_description']??'');
 if($code==='000'){
  $s=strtolower((string)($j['content']['transactions']['status']??''));
  if($s==='delivered'){
   $pc=trim((string)($j['purchased_code']??''));
   return ['status'=>'success','message'=>$desc?:'Delivered','delivery'=>$pc!==''?[['serial'=>'Code','pin'=>$pc]]:null];
  }
  return ['status'=>'pending','message'=>$desc?:'Processing'];
 }
 if(in_array($code,VT_FAILED,true)||($requery&&$code==='015'))return ['status'=>'failed','message'=>$desc?:'Failed'];
 return ['status'=>'pending','message'=>$desc?:'Processing'];
}
function vt_post(string $path,array $f,bool $requery=false):array{
 $r=http_json('POST',vt_base().$path,['api-key: '.cfg('VTPASS_API_KEY'),'secret-key: '.cfg('VTPASS_SECRET_KEY')],$f);
 return vt_norm($r['json'],$requery);
}
function vt_pay(array $f):array{return vt_post('/pay',$f);}
function vt_status(string $requestId):array{return vt_post('/requery',['request_id'=>$requestId],true);}
function vt_variations(string $serviceId):array{
 $r=http_json('GET',vt_base().'/service-variations?serviceID='.rawurlencode($serviceId),['api-key: '.cfg('VTPASS_API_KEY'),'public-key: '.cfg('VTPASS_PUBLIC_KEY')]);
 $c=$r['json']['content']??[];$v=$c['variations']??$c['varations']??[];return is_array($v)?$v:[];
}
