<?php
require_once __DIR__.'/../vtpass.php';
if(vt_configured()){ class Provider_data{
 public function purchase(array $o):array{
  $s=['MTN'=>'mtn-data','Airtel'=>'airtel-data','Glo'=>'glo-data','9mobile'=>'etisalat-data'][$o['network']??'']??null;
  $v=$o['product']['provider_code']??null;
  if(!$s||!$v)return ['status'=>'failed','message'=>'Unsupported plan.'];
  return vt_pay(['request_id'=>$o['request_id'],'serviceID'=>$s,'billersCode'=>$o['target'],'variation_code'=>$v,'phone'=>$o['target']]);
 }}}
