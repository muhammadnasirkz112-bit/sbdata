<?php
require_once __DIR__.'/../vtpass.php';
if(vt_configured()){ class Provider_electricity{
 public function purchase(array $o):array{
  [$d,$k]=array_pad(explode(' ',strtolower((string)($o['network']??'')),2),2,'');
  $s=['ikeja'=>'ikeja-electric','eko'=>'eko-electric','abuja'=>'abuja-electric','ibadan'=>'ibadan-electric'][$d]??null;
  if(!$s||!in_array($k,['prepaid','postpaid'],true))return ['status'=>'failed','message'=>'Unsupported meter type.'];
  return vt_pay(['request_id'=>$o['request_id'],'serviceID'=>$s,'billersCode'=>$o['target'],'variation_code'=>$k,'amount'=>vt_amt($o['amount_kobo']),'phone'=>$o['user_phone']]);
 }}}
