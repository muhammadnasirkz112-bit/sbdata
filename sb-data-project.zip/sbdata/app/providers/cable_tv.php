<?php
require_once __DIR__.'/../vtpass.php';
if(vt_configured()){ class Provider_cable_tv{
 public function purchase(array $o):array{
  $s=['DStv'=>'dstv','GOtv'=>'gotv','StarTimes'=>'startimes'][$o['network']??'']??null;
  $v=$o['product']['provider_code']??null;
  if(!$s||!$v)return ['status'=>'failed','message'=>'Unsupported plan.'];
  $f=['request_id'=>$o['request_id'],'serviceID'=>$s,'billersCode'=>$o['target'],'variation_code'=>$v,'phone'=>$o['user_phone']];
  if($s!=='startimes')$f['subscription_type']='change'; // new bouquet / change bouquet
  return vt_pay($f);
 }}}
