<?php
require_once __DIR__.'/../vtpass.php';
if(vt_configured()){ class Provider_airtime{
 public function purchase(array $o):array{
  $s=['MTN'=>'mtn','Airtel'=>'airtel','Glo'=>'glo','9mobile'=>'etisalat'][$o['network']??'']??null;
  if(!$s)return ['status'=>'failed','message'=>'Unsupported network.'];
  return vt_pay(['request_id'=>$o['request_id'],'serviceID'=>$s,'amount'=>vt_amt($o['amount_kobo']),'phone'=>$o['target']]);
 }}}
