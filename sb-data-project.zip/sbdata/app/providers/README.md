# Provider adapters

A service (airtime, data, electricity, cable_tv, data_card, waec_pin, neco_pin, jamb_pin, bvn_check, nin_check)
only accepts orders once an adapter exists here. Without one it reports "not available yet" and never debits a user.
`recharge_pin` needs no adapter: it is sold from the pin stock you upload in the admin panel.

Create `app/providers/<service_code>.php` containing a class named `Provider_<service_code>`:

```php
<?php
class Provider_airtime {
  // $o keys: ref, service, network, target, qty, amount_kobo, product (array|null)
  public function purchase(array $o): array {
    // Call your provider's API here (keys from .env), then return one of:
    //   ['status'=>'success','message'=>'...','delivery'=>[...optional pins/token...]]
    //   ['status'=>'failed','message'=>'...']   -> the user is refunded automatically
    //   ['status'=>'pending','message'=>'...']  -> stays pending; resolve it in Admin > Orders
    // Throwing an exception is treated as 'pending', never as success.
  }
}
```
Return `success` only after the provider has confirmed the order. Read your provider's API docs and test in their sandbox first.

## Included
`airtime`, `data`, `electricity`, `cable_tv` call VTpass (`app/vtpass.php`). They stay inactive until `VTPASS_API_KEY`, `VTPASS_PUBLIC_KEY` and `VTPASS_SECRET_KEY` are set. Order status follows VTpass: `delivered` = success; `initiated`/`pending`/unknown = pending (never an automatic success); documented "not processed" codes = failed and refunded.
