<?php
declare(strict_types=1);
require_once __DIR__.'/http.php';
/** Confirms a payment with Paystack (never trusts the browser or the webhook body alone) and credits the wallet exactly once. */
function settle_payment(string $reference):string{
 $p=q('SELECT * FROM payments WHERE reference=?',[$reference])->fetch();
 if(!$p)return 'unknown';
 if($p['status']!=='pending')return (string)$p['status'];
 $r=http_json('GET','https://api.paystack.co/transaction/verify/'.rawurlencode($reference),['Authorization: Bearer '.cfg('PAYSTACK_SECRET_KEY')]);
 $d=$r['json']['data']??null;
 if(!$d)return 'pending';
 $st=(string)($d['status']??'');
 if($st==='failed'){q("UPDATE payments SET status='failed' WHERE id=? AND status='pending'",[$p['id']]);return 'failed';}
 if($st!=='success')return 'pending';
 if((int)($d['amount']??0)!==(int)$p['amount_kobo']||($d['currency']??'NGN')!=='NGN'){
  q("UPDATE payments SET status='failed' WHERE id=? AND status='pending'",[$p['id']]);
  audit(null,'payment_mismatch','payment',$reference,['expected'=>(int)$p['amount_kobo'],'paid'=>(int)($d['amount']??0)]);return 'failed';
 }
 $pdo=db();$pdo->beginTransaction();
 try{
  $row=q("SELECT id FROM payments WHERE id=? AND status='pending' FOR UPDATE",[$p['id']])->fetch();
  if($row){
   ledger((int)$p['user_id'],'credit',(int)$p['amount_kobo'],'funding',null,'Paystack '.$reference);
   q("UPDATE payments SET status='success',paid_at=NOW() WHERE id=?",[$p['id']]);
   q('INSERT INTO notifications(user_id,title,body) VALUES(?,?,?)',[$p['user_id'],'Wallet funded','₦'.number_format((int)$p['amount_kobo']/100,2).' was added to your wallet.']);
   audit((int)$p['user_id'],'funding','payment',$reference,['amount_kobo'=>(int)$p['amount_kobo']]);
  }
  $pdo->commit();
 }catch(Throwable $e){$pdo->rollBack();throw $e;}
 return 'success';
}
