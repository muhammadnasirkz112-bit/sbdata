<?php
declare(strict_types=1);
/** Minimal JSON HTTP client (cURL). Returns ['http'=>int,'json'=>array|null]. A network error gives http 0 and json null. */
function http_json(string $method,string $url,array $headers=[],?array $body=null,int $timeout=25):array{
 $ch=curl_init($url);
 curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>$timeout,CURLOPT_CONNECTTIMEOUT=>10,
  CURLOPT_HTTPHEADER=>array_merge(['Accept: application/json'],$body!==null?['Content-Type: application/json']:[],$headers)]);
 if($body!==null)curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body));
 $raw=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
 $j=is_string($raw)?json_decode($raw,true):null;
 return ['http'=>$code,'json'=>is_array($j)?$j:null];
}
