<?php
// Command line only. Creates an admin, or promotes an existing user and sets a new password.
// Usage: php scripts/create_admin.php you@example.com "Your Name"
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/../app/core.php';
$email=strtolower(trim($argv[1]??''));$name=$argv[2]??'Administrator';
if(!filter_var($email,FILTER_VALIDATE_EMAIL)){fwrite(STDERR,"Usage: php scripts/create_admin.php you@example.com \"Your Name\"\n");exit(1);}
echo 'Choose a password (12+ characters, it will be visible as you type): ';
$pw=trim((string)fgets(STDIN));
if(strlen($pw)<12||strlen($pw)>72){fwrite(STDERR,"Password must be 12 to 72 characters.\n");exit(1);}
$h=password_hash($pw,PASSWORD_DEFAULT);
$u=q('SELECT id FROM users WHERE email=?',[$email])->fetch();
if($u){q("UPDATE users SET pass_hash=?,role='admin',status='active' WHERE id=?",[$h,$u['id']]);$id=(int)$u['id'];}
else{q("INSERT INTO users(name,email,phone,pass_hash,role) VALUES(?,?,?,?,'admin')",[$name,$email,'0000'.random_int(1000000,9999999),$h]);$id=(int)db()->lastInsertId();}
audit($id,'admin_provisioned','user',$id,['via'=>'cli']);
echo "Done. Admin account ready for $email\n";
