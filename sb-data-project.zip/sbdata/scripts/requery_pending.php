<?php
// Cron job: asks VTpass for the final status of orders that are still pending, then completes or refunds them.
// cPanel > Cron Jobs, every 5 minutes:   /usr/local/bin/php /home/USER/sbdata/scripts/requery_pending.php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/../app/core.php';require __DIR__.'/../app/orders.php';require __DIR__.'/../app/vtpass.php';
if(!vt_configured()){echo "VTpass is not configured.\n";exit(0);}
$rows=q("SELECT id,provider_ref FROM orders WHERE status='pending' AND provider_ref IS NOT NULL AND created_at<DATE_SUB(NOW(),INTERVAL 2 MINUTE) ORDER BY id LIMIT 50")->fetchAll();
$done=0;
foreach($rows as $o){
 $r=vt_status((string)$o['provider_ref']);
 if($r['status']==='pending')continue;
 if(finish_order((int)$o['id'],$r['status'],substr((string)$r['message'],0,250),isset($r['delivery'])&&is_array($r['delivery'])?$r['delivery']:null)){
  audit(null,'requery_resolved','order',$o['id'],['status'=>$r['status']]);$done++;
 }
}
echo count($rows)." pending checked, $done resolved.\n";
