# SB DATA

Wallet-based VTU platform for Nigeria: public landing page, login/registration, user dashboard, admin panel, PHP 8 + MySQL API.

**Architecture (one, consistent):** static HTML/CSS/JS front end + PHP 8.1+ JSON API + MySQL/MariaDB. This runs on ordinary cPanel shared hosting. No Node.js process is needed.

## What actually works, and what needs you

| Feature | Status |
|---|---|
| Landing page, contact form (saved to DB), login, register, logout, password hashing, sessions, CSRF, rate limits | Implemented |
| Password reset | Implemented. Sends email only if `MAIL_FROM` is set (PHP `mail()`). Otherwise the page says reset email is not set up. |
| Wallet and ledger (money stored as integer kobo, row-locked transactions, audit log) | Implemented |
| Wallet funding | **Paystack** (card, bank, transfer) once you add your key, with signature-checked webhook and server-side verification. Admin can still credit manually (Admin > Users > Fund). |
| **Recharge pins** | Implemented end to end. Admin uploads pins (encrypted at rest), users buy from stock, pins show on screen and in the receipt. |
| Airtime, Data, Electricity, Cable TV (DStv, GOtv, StarTimes) | **VTpass adapters included** (`app/providers/`). They switch on when the VTPASS keys are in `.env`. Written from VTpass's published docs, **not yet run against their sandbox**. Do that before going live (see Go-live checklist). |
| Data cards, WAEC/NECO/JAMB pins, BVN/NIN checks | Order logic exists but no adapter yet, so they show "Not available" and nobody is debited. |
| Airtime to cash | Not implemented (shown as unavailable). Needs a provider and a payout flow. |
| Email verification | Not implemented. |
| Automated tests | `tests/smoke.sh` (needs a running install). **Not executed by the author**, because the build environment had no PHP or MySQL. |

## Go-live checklist: Paystack and VTpass
**You can enter all the keys from Admin > Integrations** (no file editing). They are saved encrypted in the database and override `.env`. Each section has a Test button. `.env` still works as a fallback.

1. **Paystack:** create an account, copy the **test** secret key into `PAYSTACK_SECRET_KEY`. In Paystack > Settings > API Keys & Webhooks set the webhook URL to `https://your-domain/api/paystack/webhook`. Fund a test wallet from the dashboard with a Paystack test card, confirm the wallet is credited once. Then switch to the live key. Paystack's fees are deducted from your settlement, not from the user; the wallet is credited the amount paid.
2. **VTpass:** create a sandbox account, generate API, public and secret keys (VTpass shows public/secret only once), put them in `.env` with `VTPASS_ENV=sandbox`. Test each service with VTpass's sandbox test numbers. For live: set `VTPASS_ENV=live` with live keys, **whitelist your server IP** and **whitelist the products** you sell in your VTpass profile (otherwise VTpass returns codes 027/028 and orders are refunded), and keep the VTpass wallet funded (code 018 = low wallet).
3. **Plans:** Admin > Services and prices > "Import plans from VTpass" for Data and Cable TV, then review prices (default markup 2%). Airtime and electricity use the amount the user enters.
4. **Pending orders:** add a cron job (cPanel > Cron Jobs, every 5 minutes): `/usr/local/bin/php /home/USER/sbdata/scripts/requery_pending.php`. It asks VTpass for the final status and completes or refunds the order. Without it, pending orders wait for you in Admin > Orders.
5. **Test money flow end to end with small amounts** before announcing the site.

## 1. Requirements
PHP 8.1+ with `pdo_mysql`, `openssl`, `mbstring`, `curl`; MySQL 5.7+/MariaDB 10.3+; HTTPS (AutoSSL in cPanel is fine); Apache with `mod_rewrite` (standard on cPanel). Terminal/SSH access is optional (only for `create_admin.php`).

## 2. Configure
```
cp .env.example .env
```
Edit `.env`: database credentials, `APP_URL`, and `APP_KEY` (generate with `php -r "echo base64_encode(random_bytes(32)),PHP_EOL;"` or any tool that makes 32 random bytes in base64). **Back up APP_KEY separately**: without it stored pins cannot be decrypted. Keep `.env` outside the public folder.

## 3. Database
cPanel > MySQL Databases: create a database, a user, and give the user ALL PRIVILEGES. Then phpMyAdmin > Import `database/schema.sql` into the empty database. (Schema is a one-time install file; it has no destructive statements.)

## 4. Create the first admin (no public admin signup exists)
Terminal: `php scripts/create_admin.php you@example.com "Your Name"` and type a 12+ character password.
No terminal? Register normally on the site, then in phpMyAdmin run: `UPDATE users SET role='admin' WHERE email='you@example.com';`

## 5. Run locally
```
php -S localhost:8000 -t public public/router.php     # set COOKIE_SECURE=0 in .env for http
```
Open http://localhost:8000. Then run `bash tests/smoke.sh http://localhost:8000`.

## 6. Upload to cPanel
**Option A (best, if you can set the document root, e.g. a subdomain or addon domain):** upload the whole project to `/home/USER/sbdata/` and set the domain's document root to `/home/USER/sbdata/public`.

**Option B (primary domain with fixed `public_html`):** upload the whole project to `/home/USER/sbdata/` (outside `public_html`), then copy the **contents** of `public/` (including `.htaccess`, `api/`) into `public_html/`. Edit `public_html/api/index.php` and replace `/home/CPANEL_USER/sbdata` with your real path.

In both options `app/`, `database/`, `scripts/` and `.env` must NOT be inside a web-served folder.

## 7. Domain, SSL, PHP
cPanel > Domains to point the domain. cPanel > SSL/TLS Status > Run AutoSSL. cPanel > Select PHP Version: choose 8.1+ and enable `pdo_mysql`, `openssl`, `mbstring`. `.htaccess` forces HTTPS, so keep `COOKIE_SECURE=1`.

## 8. Operate
1. Log in at `/login.html`, open `/admin.html`.
2. **Recharge pins:** Admin > Recharge pins > choose network and value, paste `SERIAL,PIN` lines, Upload. Prices default to a 2% discount; change them in Services and prices.
3. **Fund a user:** Admin > Users > Fund (audited).
4. **Other services:** add a provider adapter, then add plans/prices in Admin > Services (airtime and bills use a free amount with min/max limits).
5. **Pending orders:** Admin > Orders > Mark done or Refund.
6. Edit the placeholder email/phone/address in `public/index.html` (Contact section).

## 9. Verify after deployment
Open the home page (services show Available/Coming soon from `/api/catalog`), register, log in, check the dashboard loads, buy a recharge pin after funding and uploading stock, confirm the admin audit log shows entries, confirm `https://your-domain/.env` and `/app/core.php` return 404/403.

## 10. Backup
Daily: cPanel > Backup, or `mysqldump -u USER -p DBNAME > backup.sql`. Also copy `.env` (especially `APP_KEY`) to a safe place. Never upload `.env` to public storage.

## 11. Troubleshooting
- **"Something went wrong"**: check `error_log` in the account root. Usually wrong DB credentials or a missing PHP extension.
- **"Server is not configured (APP_KEY)"**: set a valid 32-byte base64 key.
- **Login loops / "Session expired"**: you are on http with `COOKIE_SECURE=1`; use https.
- **API returns 404**: `.htaccess` was not copied (hidden file) or `mod_rewrite` is off.
- **Blank page with Option B**: the path in `public_html/api/index.php` is wrong.

## Security notes
Passwords: `password_hash`. SQL: prepared statements only. XSS: user text is escaped before display. CSRF: token header on every POST. Rate limits on register/login/reset/contact/orders. Sessions: HttpOnly, SameSite=Lax, Secure. Orders are idempotent (a repeated request id never charges twice). BVN/NIN: only the last four digits are stored. Run `composer`/`npm`: not needed, there are no third-party dependencies.

## Layout
`public/` web root (index, login, app, admin, api/) · `app/` PHP logic and `app/providers/` (VTpass adapters) · `database/schema.sql` (+ `migrations/` only for databases from the first version) · `scripts/` (create_admin, requery_pending) · `tests/smoke.sh`
