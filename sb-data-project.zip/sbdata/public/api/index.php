<?php
declare(strict_types=1);
// Standard layout: public/ and app/ are siblings. On cPanel with a separate public_html, set the path below.
$ROOT=is_dir(__DIR__.'/../../app')?dirname(__DIR__,2):'/home/CPANEL_USER/sbdata';
require $ROOT.'/app/core.php';
require $ROOT.'/app/orders.php';
require $ROOT.'/app/vtpass.php';
require $ROOT.'/app/paystack.php';
header('X-Content-Type-Options: nosniff');header('Cache-Control: no-store');
set_exception_handler(function(Throwable $e){error_log((string)$e);if(!headers_sent())fail('Something went wrong. Please try again.',500);});
boot();
$m=$_SERVER['REQUEST_METHOD'];$r=trim((string)($_GET['r']??''),'/');$b=body();
if($m==='POST'&&$r!=='paystack/webhook')csrf(); // the webhook is authenticated by its signature instead
$N=['MTN','Airtel','Glo','9mobile'];
switch($m.' '.$r){

case 'GET session':
 $u=user();out(['user'=>$u?pub($u):null,'csrf'=>$_SESSION['csrf']]);

case 'POST auth/register':
 limit('reg:'.ip(),10,3600);
 $n=trim((string)($b['name']??''));$e=strtolower(trim((string)($b['email']??'')));
 $p=preg_replace('/\s+/','',(string)($b['phone']??''));$pw=(string)($b['password']??'');
 if(mb_strlen($n)<2||mb_strlen($n)>100)fail('Enter your full name.');
 if(!filter_var($e,FILTER_VALIDATE_EMAIL)||strlen($e)>190)fail('Enter a valid email address.');
 if(!preg_match(PH,$p))fail('Enter an 11-digit Nigerian phone number starting with 0.');
 if(strlen($pw)<8||strlen($pw)>72)fail('Password must be 8 to 72 characters.');
 if($pw!==(string)($b['confirm']??''))fail('Passwords do not match.');
 try{q('INSERT INTO users(name,email,phone,pass_hash) VALUES(?,?,?,?)',[$n,$e,$p,password_hash($pw,PASSWORD_DEFAULT)]);}
 catch(PDOException $x){if($x->getCode()==='23000')fail('An account with this email or phone already exists.',409);throw $x;}
 $id=(int)db()->lastInsertId();session_regenerate_id(true);$_SESSION['uid']=$id;
 q('INSERT INTO notifications(user_id,title,body) VALUES(?,?,?)',[$id,'Welcome to SB DATA','Your wallet is ready. '.setting('funding_note')]);
 audit($id,'register','user',$id);out(['ok'=>true],201);

case 'POST auth/login':
 $e=strtolower(substr(trim((string)($b['email']??'')),0,190));limit('login:'.ip().':'.$e,8,900);
 $u=q('SELECT * FROM users WHERE email=?',[$e])->fetch();
 if(!$u||!password_verify((string)($b['password']??''),$u['pass_hash'])||$u['status']!=='active'){audit(null,'login_failed','user',null,['email'=>$e]);fail('Wrong email or password.',401);}
 session_regenerate_id(true);$_SESSION['uid']=(int)$u['id'];audit((int)$u['id'],'login','user',$u['id']);out(['ok'=>true,'role'=>$u['role']]);

case 'POST auth/logout':
 unset($_SESSION['uid']);session_regenerate_id(true);out(['ok'=>true]);

case 'POST auth/forgot':
 limit('fgt:'.ip(),5,3600);
 if(!env('MAIL_FROM'))fail('Password reset email is not set up on this server. Please contact support to reset your password.',501);
 $e=strtolower(trim((string)($b['email']??'')));$u=q('SELECT id FROM users WHERE email=?',[$e])->fetch();
 if($u){
  $t=bin2hex(random_bytes(32));
  q('INSERT INTO password_resets(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 1 HOUR))',[$u['id'],hash('sha256',$t)]);
  @mail($e,'Reset your SB DATA password',"Open this link within 1 hour:\n".env('APP_URL').'/login.html?reset='.$t,'From: '.env('MAIL_FROM'));
 }
 out(['message'=>'If that email has an account, a reset link is on its way.']);

case 'POST auth/reset':
 limit('rst:'.ip(),10,3600);
 $pw=(string)($b['password']??'');if(strlen($pw)<8||strlen($pw)>72)fail('Password must be 8 to 72 characters.');
 $t=q('SELECT * FROM password_resets WHERE token_hash=? AND used_at IS NULL AND expires_at>NOW()',[hash('sha256',(string)($b['token']??''))])->fetch();
 if(!$t)fail('This reset link is invalid or has expired.');
 q('UPDATE users SET pass_hash=? WHERE id=?',[password_hash($pw,PASSWORD_DEFAULT),$t['user_id']]);
 q('UPDATE password_resets SET used_at=NOW() WHERE id=?',[$t['id']]);audit((int)$t['user_id'],'password_reset','user',$t['user_id']);out(['ok'=>true]);

case 'POST contact':
 limit('ct:'.ip(),5,3600);
 $n=trim((string)($b['name']??''));$e=trim((string)($b['email']??''));$s=trim((string)($b['subject']??''));$t=trim((string)($b['message']??''));
 if(mb_strlen($n)<2||mb_strlen($n)>100)fail('Enter your name.');
 if(!filter_var($e,FILTER_VALIDATE_EMAIL))fail('Enter a valid email address.');
 if(mb_strlen($s)<3||mb_strlen($s)>150)fail('Enter a subject.');
 if(mb_strlen($t)<10||mb_strlen($t)>2000)fail('Message must be 10 to 2000 characters.');
 q('INSERT INTO contact_messages(name,email,subject,message,ip) VALUES(?,?,?,?,?)',[$n,$e,$s,$t,ip()]);out(['ok'=>true],201);

case 'GET catalog':
 $stock=[];
 foreach(q("SELECT network,face_kobo,COUNT(*) c FROM pins WHERE status='available' GROUP BY network,face_kobo")->fetchAll() as $s)$stock[$s['network'].'|'.$s['face_kobo']]=(int)$s['c'];
 $res=[];
 foreach(q('SELECT * FROM services WHERE active=1 ORDER BY sort')->fetchAll() as $s){
  $c=$s['code'];$isPin=$c==='recharge_pin';$av=$isPin||provider($c)!==null;
  $ps=q('SELECT id,network,label,face_kobo,price_kobo FROM products WHERE service_code=? AND active=1 ORDER BY network,face_kobo,id',[$c])->fetchAll();
  foreach($ps as &$p){$p['id']=(int)$p['id'];$p['price_kobo']=(int)$p['price_kobo'];if($isPin)$p['stock']=$stock[$p['network'].'|'.$p['face_kobo']]??0;}
  unset($p);
  $res[$c]=['name'=>$s['name'],'available'=>$av&&(!$ps&&SPEC[$c][1]==='plan'?false:true),'reason'=>$av?($ps||SPEC[$c][1]==='amount'?null:'No plans have been set up yet.'):'Not available yet. A provider has not been connected for this service.',
   'min_kobo'=>$s['min_kobo']!==null?(int)$s['min_kobo']:null,'max_kobo'=>$s['max_kobo']!==null?(int)$s['max_kobo']:null,'products'=>$ps];
 }
 out(['services'=>$res,'funding_note'=>setting('funding_note')]);

case 'GET dashboard':
 $u=need();$id=(int)$u['id'];
 $act=q('SELECT t.ref,t.type,t.kind,t.amount_kobo,t.created_at,o.ref oref,o.service_code,o.network,o.target,o.qty,o.status ostatus,o.delivery_enc
  FROM transactions t LEFT JOIN orders o ON o.id=t.order_id WHERE t.user_id=? ORDER BY t.id DESC LIMIT 50',[$id])->fetchAll();
 foreach($act as &$a){
  $a['amount_kobo']=(int)$a['amount_kobo'];$a['qty']=$a['qty']!==null?(int)$a['qty']:null;
  $a['delivery']=($a['ostatus']==='success'&&$a['delivery_enc'])?json_decode(dec((string)$a['delivery_enc']),true):null;unset($a['delivery_enc']);
 }
 unset($a);
 $f=array_fill(0,7,0);$sp=array_fill(0,7,0);
 foreach(q('SELECT DATEDIFF(CURDATE(),DATE(created_at)) d,type,kind,SUM(amount_kobo) s FROM transactions WHERE user_id=? AND created_at>=DATE_SUB(CURDATE(),INTERVAL 6 DAY) GROUP BY d,type,kind',[$id])->fetchAll() as $x){
  $i=6-(int)$x['d'];if($i<0||$i>6)continue;$s=(int)$x['s'];
  if($x['kind']==='admin_credit')$f[$i]+=$s;elseif($x['type']==='debit')$sp[$i]+=$s;elseif($x['kind']==='refund')$sp[$i]=max(0,$sp[$i]-$s);
 }
 $lab=[];for($k=6;$k>=0;$k--)$lab[]=date('D',strtotime("-$k day"));
 out(['user'=>pub($u),'activity'=>$act,'chart'=>['funding'=>$f,'spending'=>$sp,'labels'=>$lab],
  'notes'=>q('SELECT title,body FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 10',[$id])->fetchAll()]);

case 'POST orders':
 $u=need();limit('ord:'.$u['id'],20,60);out(order_request($u,$b),201);

case 'POST funding/init':
 $u=need();limit('fund:'.$u['id'],10,3600);
 if(!cfg('PAYSTACK_SECRET_KEY'))fail('Online funding is not set up yet. '.setting('funding_note'),503);
 $amt=kobo($b['amount']??'');if($amt<kobo('100')||$amt>kobo('500000'))fail('Enter an amount from ₦100 to ₦500,000.');
 $rf=ref('PAY');q('INSERT INTO payments(reference,user_id,amount_kobo) VALUES(?,?,?)',[$rf,$u['id'],$amt]);
 $r=http_json('POST','https://api.paystack.co/transaction/initialize',['Authorization: Bearer '.cfg('PAYSTACK_SECRET_KEY')],
  ['email'=>$u['email'],'amount'=>$amt,'currency'=>'NGN','reference'=>$rf,'callback_url'=>rtrim(env('APP_URL'),'/').'/app.html']);
 $url=$r['json']['data']['authorization_url']??null;
 if(!$url){q("UPDATE payments SET status='failed' WHERE reference=?",[$rf]);fail('Could not start the payment. Please try again.',502);}
 out(['authorization_url'=>$url]);

case 'GET funding/verify':
 $u=need();$rf=(string)($_GET['reference']??'');
 $p=q('SELECT user_id FROM payments WHERE reference=?',[$rf])->fetch();
 if(!$p||(int)$p['user_id']!==(int)$u['id'])fail('Payment not found.',404);
 out(['status'=>settle_payment($rf)]);

case 'POST paystack/webhook':
 $raw=(string)file_get_contents('php://input');$key=cfg('PAYSTACK_SECRET_KEY');
 if($key===''||!hash_equals(hash_hmac('sha512',$raw,$key),(string)($_SERVER['HTTP_X_PAYSTACK_SIGNATURE']??'')))fail('Invalid signature.',401);
 $ev=json_decode($raw,true);
 if(($ev['event']??'')==='charge.success'&&!empty($ev['data']['reference']))settle_payment((string)$ev['data']['reference']);
 out(['ok'=>true]);

// ---------------- admin ----------------
case 'GET admin/stats':
 need('admin');
 out(['users'=>cnt('SELECT COUNT(*) c FROM users'),'wallets_kobo'=>cnt('SELECT COALESCE(SUM(balance_kobo),0) c FROM users'),
  'pins_available'=>cnt("SELECT COUNT(*) c FROM pins WHERE status='available'"),'messages'=>cnt('SELECT COUNT(*) c FROM contact_messages'),
  'orders'=>q('SELECT status,COUNT(*) c FROM orders GROUP BY status')->fetchAll()]);

case 'GET admin/users':
 need('admin');$s=trim((string)($_GET['q']??''));$l='%'.addcslashes($s,'%_\\').'%';
 out(q('SELECT id,name,email,phone,role,status,balance_kobo,created_at FROM users WHERE (?=\'\' OR name LIKE ? OR email LIKE ? OR phone LIKE ?) ORDER BY id DESC LIMIT 100',[$s,$l,$l,$l])->fetchAll());

case 'POST admin/credit':
 $a=need('admin');$uid=(int)($b['user_id']??0);$amt=kobo($b['amount']??'');
 if($amt<100||$amt>kobo('5000000'))fail('Amount must be between ₦1 and ₦5,000,000.');
 $pdo=db();$pdo->beginTransaction();
 try{
  if(!q('SELECT id FROM users WHERE id=? FOR UPDATE',[$uid])->fetch())throw new RuntimeException('User not found.');
  $nb=ledger($uid,'credit',$amt,'admin_credit',null,substr((string)($b['note']??''),0,200));
  q('INSERT INTO notifications(user_id,title,body) VALUES(?,?,?)',[$uid,'Wallet funded','₦'.number_format($amt/100,2).' was added to your wallet.']);
  audit((int)$a['id'],'admin_credit','user',$uid,['amount_kobo'=>$amt,'note'=>substr((string)($b['note']??''),0,200)]);
  $pdo->commit();
 }catch(Throwable $e){$pdo->rollBack();if($e instanceof RuntimeException&&!($e instanceof PDOException))fail($e->getMessage(),404);throw $e;}
 out(['balance_kobo'=>$nb]);

case 'POST admin/user-status':
 $a=need('admin');$uid=(int)($b['user_id']??0);$st=(string)($b['status']??'');
 if(!in_array($st,['active','suspended'],true)||$uid===(int)$a['id'])fail('Not allowed.');
 q('UPDATE users SET status=? WHERE id=?',[$st,$uid]);audit((int)$a['id'],'user_status','user',$uid,['status'=>$st]);out(['ok'=>true]);

case 'GET admin/services':
 need('admin');$ss=q('SELECT * FROM services ORDER BY sort')->fetchAll();
 foreach($ss as &$s){$s['provider_connected']=$s['code']==='recharge_pin'||provider($s['code'])!==null;}unset($s);
 out(['services'=>$ss,'products'=>q('SELECT * FROM products ORDER BY service_code,network,face_kobo,id')->fetchAll()]);

case 'POST admin/service':
 $a=need('admin');$code=(string)($b['code']??'');
 $min=($b['min']??'')!==''?kobo($b['min']):null;$max=($b['max']??'')!==''?kobo($b['max']):null;
 q('UPDATE services SET active=?,min_kobo=?,max_kobo=? WHERE code=?',[empty($b['active'])?0:1,$min,$max,$code]);
 audit((int)$a['id'],'service_update','service',$code,$b);out(['ok'=>true]);

case 'POST admin/product':
 $a=need('admin');$price=kobo($b['price']??'');
 if(!empty($b['id'])){q('UPDATE products SET price_kobo=?,active=? WHERE id=?',[$price,empty($b['active'])?0:1,(int)$b['id']]);$id=(int)$b['id'];}
 else{
  $code=(string)($b['service_code']??'');if(!isset(SPEC[$code])||SPEC[$code][1]!=='plan'||$code==='recharge_pin')fail('Choose a service that uses plans.');
  $label=trim((string)($b['label']??''));if($label===''||mb_strlen($label)>80)fail('Enter a plan name.');
  $net=trim((string)($b['network']??''));if($net!==''&&!preg_match('/^[A-Za-z0-9 ]{1,20}$/',$net))fail('Invalid network.');
  q('INSERT INTO products(service_code,network,label,price_kobo) VALUES(?,?,?,?)',[$code,$net?:null,$label,$price]);$id=(int)db()->lastInsertId();
 }
 audit((int)$a['id'],'product_update','product',$id,['price_kobo'=>$price]);out(['ok'=>true]);

case 'POST admin/vtpass-sync':
 $a=need('admin');$svc=(string)($b['service']??'');
 $map=['data'=>['MTN'=>'mtn-data','Airtel'=>'airtel-data','Glo'=>'glo-data','9mobile'=>'etisalat-data'],'cable_tv'=>['DStv'=>'dstv','GOtv'=>'gotv','StarTimes'=>'startimes']][$svc]??null;
 if(!$map)fail('Choose Data or Cable TV.');
 if(!vt_configured())fail('VTpass keys are not set in .env.',503);
 $mk=(float)($b['markup']??0);if($mk<0||$mk>50)fail('Markup must be from 0 to 50.');
 $n=0;
 foreach($map as $net=>$sid){
  foreach(vt_variations($sid) as $v){
   $c=(string)($v['variation_code']??'');$amt=(float)($v['variation_amount']??0);$nm=mb_substr((string)($v['name']??$c),0,80);
   if($c===''||$amt<=0)continue;
   if(q('SELECT id FROM products WHERE service_code=? AND network=? AND provider_code=?',[$svc,$net,$c])->fetch())continue;
   q('INSERT INTO products(service_code,network,label,face_kobo,price_kobo,provider_code) VALUES(?,?,?,?,?,?)',[$svc,$net,$nm,(int)round($amt*100),(int)ceil($amt*100*(1+$mk/100)),$c]);$n++;
  }
 }
 audit((int)$a['id'],'vtpass_sync','service',$svc,['added'=>$n,'markup'=>$mk]);out(['added'=>$n]);

case 'GET admin/integrations':
 need('admin');$o=[];
 foreach(INT_KEYS as $k=>$secret){$v=cfg($k);$o[$k]=$secret?($v!==''?'••••'.substr($v,-4):''):$v;}
 out(['values'=>$o,'webhook'=>rtrim(env('APP_URL'),'/').'/api/paystack/webhook']);

case 'POST admin/integrations':
 $a=need('admin');$changed=[];
 foreach(INT_KEYS as $k=>$secret){
  if(!isset($b[$k]))continue;$v=trim((string)$b[$k]);if($v==='')continue; // blank keeps the saved value
  if($k==='VTPASS_ENV'&&!in_array($v,['sandbox','live'],true))fail('Environment must be sandbox or live.');
  if(strlen($v)>200||preg_match('/\s/',$v))fail('That value looks invalid ('.$k.').');
  q('INSERT INTO settings(k,v) VALUES(?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)',['cfg_'.$k,$secret?enc($v):$v]);$changed[]=$k;
 }
 audit((int)$a['id'],'integrations_update','settings',null,['changed'=>$changed]);out(['ok'=>true]);

case 'POST admin/integrations-test':
 need('admin');$w=(string)($b['which']??'');
 if($w==='paystack'){
  if(cfg('PAYSTACK_SECRET_KEY')==='')out(['ok'=>false,'message'=>'No Paystack key saved yet.']);
  $r=http_json('GET','https://api.paystack.co/transaction/verify/sbdata-key-check',['Authorization: Bearer '.cfg('PAYSTACK_SECRET_KEY')]);
  if($r['http']===0)out(['ok'=>false,'message'=>'Could not reach Paystack from this server.']);
  out($r['http']===401?['ok'=>false,'message'=>'Paystack rejected this key.']:['ok'=>true,'message'=>'Paystack accepted the key.']);
 }
 if($w==='vtpass'){
  if(!vt_configured())out(['ok'=>false,'message'=>'Save the API key, public key and secret key first.']);
  $n=count(vt_variations('mtn-data'));
  out($n>0?['ok'=>true,'message'=>'VTpass ('.cfg('VTPASS_ENV','sandbox').') connected. '.$n.' MTN data plans found.']:['ok'=>false,'message'=>'VTpass returned no plans. Check the keys and the environment (sandbox or live).']);
 }
 fail('Unknown test.');

case 'GET admin/pins':
 need('admin');out(q('SELECT network,face_kobo,status,COUNT(*) c FROM pins GROUP BY network,face_kobo,status ORDER BY network,face_kobo')->fetchAll());

case 'POST admin/pins':
 $a=need('admin');$n=(string)($b['network']??'');if(!in_array($n,$N,true))fail('Choose a network.');
 $face=kobo($b['face']??'');if($face<100)fail('Enter the card value in naira.');
 $lines=preg_split('/\r?\n/',trim((string)($b['lines']??'')));if(count($lines)>2000)fail('Upload at most 2000 pins at a time.');
 $ok=$dup=$bad=0;
 foreach($lines as $l){
  $l=trim($l);if($l==='')continue;$x=preg_split('/[,\s;]+/',$l);
  if(count($x)!==2||!preg_match('/^[A-Za-z0-9-]{4,40}$/',$x[0])||!preg_match('/^\d{8,20}$/',$x[1])){$bad++;continue;}
  q('INSERT IGNORE INTO pins(network,face_kobo,serial,pin_enc) VALUES(?,?,?,?)',[$n,$face,$x[0],enc($x[1])])->rowCount()?$ok++:$dup++;
 }
 audit((int)$a['id'],'pins_upload','pin',$n,['face_kobo'=>$face,'added'=>$ok,'duplicates'=>$dup,'invalid'=>$bad]);out(compact('ok','dup','bad'));

case 'GET admin/orders':
 need('admin');$st=(string)($_GET['status']??'');
 out(q('SELECT o.id,o.ref,o.service_code,o.network,o.target,o.qty,o.amount_kobo,o.status,o.message,o.created_at,u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE (?=\'\' OR o.status=?) ORDER BY o.id DESC LIMIT 100',[$st,$st])->fetchAll());

case 'POST admin/order-resolve':
 $a=need('admin');$st=(string)($b['status']??'');if(!in_array($st,['success','failed'],true))fail('Invalid status.');
 $pdo=db();$pdo->beginTransaction();
 $o=q("SELECT * FROM orders WHERE id=? AND status='pending' FOR UPDATE",[(int)($b['order_id']??0)])->fetch();
 if(!$o){$pdo->rollBack();fail('Pending order not found.',404);}
 try{
  if($st==='failed')ledger((int)$o['user_id'],'credit',(int)$o['amount_kobo'],'refund',(int)$o['id'],'Refund '.$o['ref']);
  q('UPDATE orders SET status=?,message=? WHERE id=?',[$st,substr((string)($b['note']??''),0,250),$o['id']]);
  audit((int)$a['id'],'order_resolve','order',$o['id'],['status'=>$st]);$pdo->commit();
 }catch(Throwable $e){$pdo->rollBack();throw $e;}
 out(['ok'=>true]);

case 'GET admin/messages':
 need('admin');out(q('SELECT id,name,email,subject,message,created_at FROM contact_messages ORDER BY id DESC LIMIT 100')->fetchAll());

case 'GET admin/audit':
 need('admin');out(q('SELECT a.id,a.action,a.entity,a.entity_id,a.meta,a.ip,a.created_at,u.email FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 150')->fetchAll());

default: fail('Not found.',404);
}
