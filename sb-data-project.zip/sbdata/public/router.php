<?php
// Local testing only:  php -S localhost:8000 -t public public/router.php
$p=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if(str_starts_with($p,'/api/')&&$p!=='/api/index.php'){$_GET['r']=substr($p,5);require __DIR__.'/api/index.php';return true;}
return false;
