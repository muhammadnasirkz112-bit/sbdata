#!/usr/bin/env bash
# Basic end-to-end checks against a running install.  Usage: bash tests/smoke.sh http://localhost:8000
# Requires curl and python3. Creates one throwaway user. Run on a test database, not production.
B=${1:-http://localhost:8000}; J=$(mktemp); pass=0; fail=0
ok(){ if [ "$2" = "$3" ]; then echo "PASS $1"; pass=$((pass+1)); else echo "FAIL $1 (got $2, want $3)"; fail=$((fail+1)); fi; }
code(){ curl -s -o /tmp/smoke.out -w '%{http_code}' -b "$J" -c "$J" "$@"; }
CSRF=$(curl -s -c "$J" "$B/api/session" | python3 -c 'import sys,json;print(json.load(sys.stdin)["csrf"])')
H=(-H "Content-Type: application/json" -H "X-CSRF-Token: $CSRF")
E="smoke$RANDOM@example.com"; P="08$(shuf -i 10000000-99999999 -n1)"
ok "protected dashboard needs login" "$(code "$B/api/dashboard")" 401
ok "admin route needs login"         "$(code "$B/api/admin/stats")" 401
ok "POST without CSRF is rejected"   "$(code -X POST -H 'Content-Type: application/json' -d '{}' "$B/api/auth/login")" 419
ok "wrong login fails"               "$(code -X POST "${H[@]}" -d '{"email":"nobody@example.com","password":"wrongpass"}' "$B/api/auth/login")" 401
ok "weak password rejected"          "$(code -X POST "${H[@]}" -d "{\"name\":\"Test User\",\"email\":\"$E\",\"phone\":\"$P\",\"password\":\"short\",\"confirm\":\"short\"}" "$B/api/auth/register")" 400
ok "register"                        "$(code -X POST "${H[@]}" -d "{\"name\":\"Test User\",\"email\":\"$E\",\"phone\":\"$P\",\"password\":\"Passw0rd!long\",\"confirm\":\"Passw0rd!long\"}" "$B/api/auth/register")" 201
ok "duplicate account rejected"      "$(code -X POST "${H[@]}" -d "{\"name\":\"Test User\",\"email\":\"$E\",\"phone\":\"$P\",\"password\":\"Passw0rd!long\",\"confirm\":\"Passw0rd!long\"}" "$B/api/auth/register")" 409
ok "dashboard after register"        "$(code "$B/api/dashboard")" 200
ok "ordinary user blocked from admin" "$(code "$B/api/admin/stats")" 403
ok "catalog is public"               "$(code "$B/api/catalog")" 200
ok "airtime unavailable without provider" "$(code -X POST "${H[@]}" -d '{"service":"airtime","target":"08012345678","amount":"500","idem":"smoke-airtime-1"}' "$B/api/orders")" 503
ok "recharge pin with empty wallet is refused" "$(code -X POST "${H[@]}" -d '{"service":"recharge_pin","product_id":1,"qty":1,"idem":"smoke-pin-0001"}' "$B/api/orders")" 409
echo "$pass passed, $fail failed"; rm -f "$J"; [ "$fail" -eq 0 ]
