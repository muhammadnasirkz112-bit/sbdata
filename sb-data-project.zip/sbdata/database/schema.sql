-- SB DATA schema. MySQL 5.7+/8 or MariaDB 10.3+. Run once on an EMPTY database.
SET NAMES utf8mb4;
CREATE TABLE users(
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(15) NOT NULL UNIQUE,
 pass_hash VARCHAR(255) NOT NULL,
 role ENUM('user','admin') NOT NULL DEFAULT 'user',
 status ENUM('active','suspended') NOT NULL DEFAULT 'active',
 balance_kobo BIGINT UNSIGNED NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE services(
 code VARCHAR(30) PRIMARY KEY, name VARCHAR(60) NOT NULL, category VARCHAR(30) NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1, min_kobo BIGINT UNSIGNED NULL, max_kobo BIGINT UNSIGNED NULL, sort INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE products(
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 service_code VARCHAR(30) NOT NULL, network VARCHAR(20) NULL, label VARCHAR(80) NOT NULL,
 face_kobo BIGINT UNSIGNED NOT NULL DEFAULT 0, price_kobo BIGINT UNSIGNED NOT NULL, provider_code VARCHAR(80) NULL, active TINYINT(1) NOT NULL DEFAULT 1,
 FOREIGN KEY(service_code) REFERENCES services(code), INDEX(service_code,network)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE orders(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, ref VARCHAR(20) NOT NULL UNIQUE,
 user_id INT UNSIGNED NOT NULL, service_code VARCHAR(30) NOT NULL, product_id INT UNSIGNED NULL,
 network VARCHAR(20) NULL, target VARCHAR(40) NULL, qty SMALLINT UNSIGNED NOT NULL DEFAULT 1,
 amount_kobo BIGINT UNSIGNED NOT NULL, status ENUM('pending','success','failed') NOT NULL,
 message VARCHAR(255) NULL, delivery_enc TEXT NULL, provider_ref VARCHAR(64) NULL, idem VARCHAR(64) NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(user_id,idem), INDEX(user_id,id), INDEX(status), FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE transactions(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, ref VARCHAR(20) NOT NULL UNIQUE,
 user_id INT UNSIGNED NOT NULL, type ENUM('credit','debit') NOT NULL, amount_kobo BIGINT UNSIGNED NOT NULL,
 balance_after_kobo BIGINT UNSIGNED NOT NULL, kind ENUM('order','refund','admin_credit','funding') NOT NULL,
 order_id BIGINT UNSIGNED NULL, note VARCHAR(200) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX(user_id,id), FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE payments(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, reference VARCHAR(30) NOT NULL UNIQUE, user_id INT UNSIGNED NOT NULL,
 amount_kobo BIGINT UNSIGNED NOT NULL, status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, paid_at DATETIME NULL, INDEX(user_id), FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE pins(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, network VARCHAR(20) NOT NULL, face_kobo BIGINT UNSIGNED NOT NULL,
 serial VARCHAR(40) NOT NULL, pin_enc VARCHAR(255) NOT NULL, status ENUM('available','sold') NOT NULL DEFAULT 'available',
 order_id BIGINT UNSIGNED NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(network,serial), INDEX(network,face_kobo,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE notifications(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, title VARCHAR(120) NOT NULL,
 body VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(user_id,id),
 FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE password_resets(
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL,
 expires_at DATETIME NOT NULL, used_at DATETIME NULL, INDEX(token_hash), FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE contact_messages(
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(190) NOT NULL,
 subject VARCHAR(150) NOT NULL, message TEXT NOT NULL, ip VARCHAR(45) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE audit_logs(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, actor_id INT UNSIGNED NULL, action VARCHAR(40) NOT NULL,
 entity VARCHAR(30) NULL, entity_id VARCHAR(40) NULL, meta TEXT NULL, ip VARCHAR(45) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX(actor_id), INDEX(action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE settings(k VARCHAR(40) PRIMARY KEY, v TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE rate_limits(k VARCHAR(255) PRIMARY KEY, hits INT UNSIGNED NOT NULL, reset_at INT UNSIGNED NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO services(code,name,category,min_kobo,max_kobo,sort) VALUES
('airtime','Airtime','Top up',5000,5000000,1),('data','Data','Top up',NULL,NULL,2),('data_card','Data card','Top up',NULL,NULL,3),
('recharge_pin','Recharge pin','Top up',NULL,NULL,4),('electricity','Electricity','Bills and TV',50000,10000000,5),
('cable_tv','Cable TV','Bills and TV',50000,6000000,6),('waec_pin','WAEC pin','Education',NULL,NULL,7),
('neco_pin','NECO pin','Education',NULL,NULL,8),('jamb_pin','JAMB pin','Education',NULL,NULL,9),
('bvn_check','BVN check','Verification',NULL,NULL,10),('nin_check','NIN check','Verification',NULL,NULL,11);
-- Recharge pin catalogue: 4 networks x 4 values at a 2% discount. Change prices later in the admin panel.
INSERT INTO products(service_code,network,label,face_kobo,price_kobo)
SELECT 'recharge_pin',n.v,CONCAT('₦',d.v,' pin'),d.v*100,d.v*98 FROM
(SELECT 'MTN' v UNION ALL SELECT 'Airtel' UNION ALL SELECT 'Glo' UNION ALL SELECT '9mobile') n
CROSS JOIN (SELECT 100 v UNION ALL SELECT 200 UNION ALL SELECT 500 UNION ALL SELECT 1000) d;
INSERT INTO settings(k,v) VALUES('funding_note','Automatic funding is not connected yet. Contact support to fund your wallet.');
