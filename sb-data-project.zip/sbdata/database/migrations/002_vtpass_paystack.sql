-- Only for databases created from the FIRST version of schema.sql. Fresh installs already include this.
ALTER TABLE transactions MODIFY kind ENUM('order','refund','admin_credit','funding') NOT NULL;
ALTER TABLE orders ADD COLUMN provider_ref VARCHAR(64) NULL AFTER delivery_enc;
ALTER TABLE products ADD COLUMN provider_code VARCHAR(80) NULL AFTER price_kobo;
CREATE TABLE payments(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, reference VARCHAR(30) NOT NULL UNIQUE, user_id INT UNSIGNED NOT NULL,
 amount_kobo BIGINT UNSIGNED NOT NULL, status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, paid_at DATETIME NULL, INDEX(user_id), FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
